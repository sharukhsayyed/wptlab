let s = "Rainbow"
let s1 = new String("Rainbow")
if(s==s1){
    console.log("same");
}
else{
    console.log("different");
}